package Coding;

import java.awt.Image;
import java.awt.Color;
import java.awt.Graphics; 
import javax.swing.JFrame; 

public class test extends JFrame  {
	
	private static final long serialVersionUID = 1L; 
	Image newimg; 
	test() {
		
		
	}
	
	test(Image m) {
		
		newimg=m;
		} 
	
	public void paint(Graphics g) {
		
		g.drawImage(newimg,100,100,null); 
	}
	
	public static void main(String args[]) {
		
		test t=new test();
		t.setSize(1035,740);
		t.getContentPane().setBackground(Color.gray);
		t.setVisible(true); 
	}
	
}

