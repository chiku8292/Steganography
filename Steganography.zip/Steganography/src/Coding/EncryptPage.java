package Coding;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;

public class EncryptPage extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    private JLabel code_label, secret_label, picture_lable;
    private JLabel label;
    private JTextField code_text, secret_text, picture_text;
    private JButton picture_load_button, hide_button, home_button;
    String filepath = "", secret_code = "", secret_info = "", user_key = "";

    Container con = null;
    JLabel j1;

    byte img_byte[] = new byte[6000];

    FileDialog fd;

    /// variable for creating an image from an integer array///

    Image img;
    Dimension d;
    int iw, ih;
    int px[];
    int hist[] = new int[256];
    int max_hist = 0;
    boolean ok;
    static Image newimg;int key,k;

    EncryptPage() {

        super("Encrypt");
        con = getContentPane();
        con.setLocale(null);

        label = new JLabel("<html><font color=#ffb3b3 >STEGANOGRAPHY: ENCRYPTION</font></html>");
        label.setBounds(225, 1, 500, 300);
        label.setFont(new Font("Times New Roman", Font.PLAIN, 30));

        code_label = new JLabel("<html><font color=white >SECURITY CODE</font></html>");
        code_label.setBounds(230, 200, 150, 50);
        code_label.setFont(new Font("Times New Roman", Font.PLAIN, 15));

        code_text = new JTextField();
        code_text.setBounds(400, 200, 250, 50);

        secret_label = new JLabel("<html><font color=white >SECURITY INFORMATION</font></html>");
        secret_label.setBounds(230, 300, 150, 50);
        secret_label.setFont(new Font("Times New Roman", Font.PLAIN, 15));

        secret_text = new JTextField(200);
        secret_text.setBounds(400, 300, 250, 50);

        picture_lable = new JLabel("<html><font color=white >PICTURE PATH</font></html>");
        picture_lable.setBounds(230, 400, 250, 50);
        picture_lable.setFont(new Font("Times New Roman", Font.PLAIN, 15));

        picture_text = new JTextField(200);
        picture_text.setBounds(400, 400, 250, 50);

        picture_load_button = new JButton("<html><font color=blue >UPLOAD</font></html>");
        picture_load_button.setBounds(700, 400, 150, 30);
        picture_load_button.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        picture_load_button.addActionListener(this);

        hide_button = new JButton("<html><font color=blue >HIDE</font></html>");
        hide_button.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        hide_button.setBounds(400, 500, 150, 30);
        hide_button.addActionListener(this);

        home_button = new JButton("<html><font color=blue >HOME</font></html>");
        home_button.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        home_button.setBounds(700, 500, 150, 30);
        home_button.addActionListener(this);

        j1 = new JLabel();
        j1.setBounds(700, 600, 150, 30);

        fd = new FileDialog(new JFrame());

        con.add(label);
        con.add(code_label);
        con.add(code_text);
        con.add(secret_label);
        con.add(secret_text);
        con.add(picture_lable);
        con.add(picture_text);
        con.add(picture_load_button);
        con.add(hide_button);
        con.add(home_button);
        con.add(j1);

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == picture_load_button) {

            fd.setVisible(true);
            filepath = fd.getDirectory() + fd.getFile();
            picture_text.setText(filepath);

        }

        else if (ae.getSource() == hide_button) {

            int starflag = 0;
            String secret_code = code_text.getText();

            for (int i = 0; i < secret_code.length(); i++) {

                if (secret_code.charAt(i) == '*') {

                    starflag = 1;
                }
            }

            if (starflag == 0) {

                secret_info = secret_text.getText();
                user_key = secret_code + "*" + new String(" " + secret_info.length());

                System.out.println("user_key" + user_key);

                String secret_code_info = user_key + "*" + secret_info + "*";
                byte secret_byte_array[] = secret_code_info.getBytes();
                int secret_int_array[] = new int[secret_byte_array.length];

                try {

                    if (filepath.equals("") && (secret_text.getText().equals("")))
                        JOptionPane.showMessageDialog(null, "image and secret information are empty.  Enter them");

                    else if (filepath.length() == 0 && (secret_text.getText()).length() > 0)
                        JOptionPane.showMessageDialog(null, "load an image");

                    else {

                        ImageIcon ic = new ImageIcon(filepath);
                        img = ic.getImage();
                        iw = img.getWidth(null);
                        ih = img.getHeight(null);

                        px = new int[iw * ih];
                        PixelGrabber pg = new PixelGrabber(img, 0, 0, iw, ih, px, 0, iw);
                        ColorModel cm = pg.getColorModel();

                        int ww = pg.getWidth();
                        int hh = pg.getHeight();
                        pg.grabPixels();

                        int key = secret_byte_array.length;
                        int k = key;
                        int j = 0;

                        for (int i = 0; i <= px.length; i++) {

                            if ((i % 20) == 0 && k > 0) {

                                secret_int_array[j] = (int) secret_byte_array[j];
                                System.out.println("user_key: " + secret_int_array[j]);

                                px[i] = secret_int_array[j];

                                j++;
                                k--;

                            }
                        }

                        newimg = con.createImage(new MemoryImageSource(ww, hh, cm, px, 0, ww));

                        j1.setIcon(new ImageIcon(newimg));
                        JOptionPane.showMessageDialog(null, "your secret code: " + user_key + "");

                        MediaTracker mt = new MediaTracker(new Container());
                        mt.addImage(newimg, 0);
                        mt.waitForID(0);

                        int thumbWidth = 400;// Integer.parseInt(400)
                        int thumbHeight = 400;// Integer.parseInt(400)
                        double thumbRatio = (double) thumbWidth / (double) thumbHeight;

                        int imageWidth = newimg.getWidth(null);
                        int imageHeight = newimg.getWidth(null);
                        double imageRatio = (double) imageWidth / (double) imageHeight;

                        if (thumbRatio < imageRatio) {

                            thumbHeight = (int) (thumbWidth / imageRatio);
                        }

                        else {

                            thumbWidth = (int) (thumbWidth * imageRatio);

                        }

                        /*
                         * draw original image ton thumbnail image object and
                         * scale it to the new size on-the-fly
                         */

                        BufferedImage ti = new BufferedImage(newimg.getWidth(null), newimg.getHeight(null),
                                BufferedImage.TYPE_INT_RGB);

                        Graphics2D graphics2D = ti.createGraphics();
                        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                                RenderingHints.VALUE_INTERPOLATION_BILINEAR);

                        // save thumbnail image to OUTFILE

                        File f = new File("useful.jpg");

                        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(f));
                        ImageIO.write(ti, secret_code_info, f);
                        int quality = 80;
                        quality = Math.max(0, Math.min(quality, 100));
                        out.close();

                        System.out.println("done");

                        test t = new test(newimg);
                        t.setSize(1035, 790);
                        t.getContentPane().setBackground(Color.GRAY);
                        t.setVisible(false);
                    }

                } catch (Exception e) {

                    System.out.println(e);

                }

            }

            else
                JOptionPane.showMessageDialog(null, "Do not enter '*' in secrect code");

        }

        else {

            this.dispose();

            Encrypt_frame ef = new Encrypt_frame();
            ef.setSize(1035, 790);
            ef.getContentPane().setBackground(Color.pink);
            ef.setVisible(true);

        }
    }

    public static void main(String args[]) {

        EncryptPage ep = new EncryptPage();
        ep.setSize(1035, 740);
        ep.getContentPane().setBackground(Color.pink);
        ep.setVisible(true);

    }

}
