package Coding;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Encrypt_frame extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JLabel label;
    private JButton encrypt, decryptmsg;

    Encrypt_frame() {
        super("Digital Image Steganography");
        Container con = getContentPane();
        con.setLayout(null);
        label = new JLabel("<html><font color=black >STEGANOGRAPHY</font></html>");
        label.setBounds(325, 1, 500, 300);
        label.setFont(new Font("Times New Roman", Font.PLAIN, 50));
        encrypt = new JButton("<html><font color=#007399 >ENCRYPT</font></html>");
        encrypt.addActionListener(this);
        encrypt.setBounds(300, 300, 150, 50);
        encrypt.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        decryptmsg = new JButton("<html><font color=#007399 >DECRYPT</font></html>");
        decryptmsg.addActionListener(this);
        decryptmsg.setBounds(600, 300, 150, 50);
        decryptmsg.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        con.add(label);
        con.add(encrypt);
        con.add(decryptmsg);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == encrypt) {
            this.dispose();
            EncryptPage ep = new EncryptPage();
            ep.setSize(1035, 790);
            ep.getContentPane().setBackground(Color.gray);
            ep.setVisible(true);
        }
        if (ae.getSource() == decryptmsg) {
            this.dispose();
            DecryptPage dp = new DecryptPage();
            dp.setSize(1035, 790);
            dp.getContentPane().setBackground(Color.gray);
            dp.setVisible(true);
        }
    }

    public static void main(String[] args) {
        Encrypt_frame ef = new Encrypt_frame();
        ef.setSize(1035, 790);
        ef.getContentPane().setBackground(Color.gray);
        ef.setVisible(true);
    }
}
